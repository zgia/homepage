=== Plugin Name ===
Contributors: zGia!
Donate link: http://none
Tags: plugin time
Requires at least: 2.0.2
Tested up to: 2.3.2
Stable tag: zgia-babyage-0.2

Show baby's age.

== Description ==

This plugin can show your baby's age in wp page, just like: Dear baby is 6 months and 1 days old.
Your can find it here: http://yuntian.name/?p=5.
And you canemail: wuliuqiba@gmail.com.
Thanks for using the plugin.


== Installation ==

1. Unzip babyage.0.2.zip to WPDIR/wp-content/plugins/babyage/. If there is no babyage folder, please create it. You will find 5 files in it.
2. Edit config.php, and select your own language, timezone, and baby's birthday: $bornYear, $bornMonth, $bornDay.
3 Add "<span id="babyage" style="color: red; font-weight: bold;"></span>" to your theme file, such as header.php, sidebar.php, etc.
4. Active the plugin.

== Screenshots ==

1. preview

== Frequently Asked Questions ==
Please view: http://yuntian.name/?p=5.