<?php

// Language file
require_once(CURRENTDIR . '/language_en.php');

// Beijing/Shanghai, China, GMT +0800
define('TIMEZONE', 8);

// Date on birth
$bornYear = 2007;
$bornMonth = 7;
$bornDay = 17;

?>