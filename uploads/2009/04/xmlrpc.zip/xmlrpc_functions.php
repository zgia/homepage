<?php
function get_option($param)
{
    global $blog_options;
    return $blog_options[$param]['option'];
}
function site_url($file)
{
    return DEDECMS_URL . '/' . $file;
}
function bloginfo_rss($file)
{
    echo DEDECMS_URL;
}
function __($str)
{
    return $str;
}


/**
 * logIO() - Writes logging info to a file.
 *
 * @uses $xmlrpc_logging
 *
 * @param string $io Whether input or output
 * @param string $msg Information describing logging reason.
 * @return bool Always return true
 */
function logIO($io, $msg)
{
    global $xmlrpc_logging;
    if ($xmlrpc_logging)
    {
        $fp = fopen("./xmlrpc.log", "a+");
        $date = gmdate("Y-m-d H:i:s ", time() + intval(get_option('gmt_offset'))*3600);
        $iot = ($io == "I") ? " Input: " : " Output: ";
        fwrite($fp, "\n\n" . $date . $iot . $msg);
        fclose($fp);
    }
    return true;
}

/**
 * Returns a date in the GMT equivalent.
 *
 * Requires and returns a date in the Y-m-d H:i:s format. Simply subtracts the
 * value of the 'gmt_offset' option.
 *
 * @uses get_option() to retrieve the the value of 'gmt_offset'.
 * @param string $string The date to be converted.
 * @return string GMT version of the date provided.
 */
function get_gmt_from_date($string)
{
    preg_match('#([0-9]{1,4})-([0-9]{1,2})-([0-9]{1,2}) ([0-9]{1,2}):([0-9]{1,2}):([0-9]{1,2})#', $string, $matches);
    $string_time = gmmktime($matches[4], $matches[5], $matches[6], $matches[2], $matches[3], $matches[1]);
    $string_gmt = gmdate('Y-m-d H:i:s', $string_time - get_option('gmt_offset') * 3600);
    return $string_gmt;
}

/**
 * Converts a GMT date into the correct format for the blog.
 *
 * Requires and returns in the Y-m-d H:i:s format. Simply adds the value of
 * gmt_offset.
 *
 * @param string $string The date to be converted.
 * @return string Formatted date relative to the GMT offset.
 */
function get_date_from_gmt($string)
{
    preg_match('#([0-9]{1,4})-([0-9]{1,2})-([0-9]{1,2}) ([0-9]{1,2}):([0-9]{1,2}):([0-9]{1,2})#', $string, $matches);
    $string_time = gmmktime($matches[4], $matches[5], $matches[6], $matches[2], $matches[3], $matches[1]);
    $string_localtime = gmdate('Y-m-d H:i:s', $string_time + get_option('gmt_offset') * 3600);
    return $string_localtime;
}

/**
 * Computes an offset in seconds from an iso8601 timezone.
 *
 * @param string $timezone Either 'Z' for 0 offset or '��hhmm'.
 * @return int|float The offset in seconds.
 */
function iso8601_timezone_to_offset($timezone)
{
    // $timezone is either 'Z' or '[+|-]hhmm'
    if ($timezone == 'Z')
    {
        $offset = 0;
    }
    else
    {
        $sign = (substr($timezone, 0, 1) == '+') ? 1 : -1;
        $hours = intval(substr($timezone, 1, 2));
        $minutes = intval(substr($timezone, 3, 4)) / 60;
        $offset = $sign * 3600 * ($hours + $minutes);
    }
    return $offset;
}

/**
 * Converts an iso8601 date to MySQL DateTime format used by post_date[_gmt].
 *
 * @param string $date_string Date and time in ISO 8601 format {@link http://en.wikipedia.org/wiki/ISO_8601}.
 * @param string $timezone Optional. If set to GMT returns the time minus gmt_offset. Default is 'user'.
 * @return string The date and time in MySQL DateTime format - Y-m-d H:i:s.
 */
function iso8601_to_datetime($date_string, $timezone = 'user')
{
    $timezone = strtolower($timezone);

    if ($timezone == 'gmt')
    {

        preg_match('#([0-9]{4})([0-9]{2})([0-9]{2})T([0-9]{2}):([0-9]{2}):([0-9]{2})(Z|[\+|\-][0-9]{2,4}){0,1}#', $date_string, $date_bits);

        if (!empty($date_bits[7]))
        { // we have a timezone, so let's compute an offset
            $offset = iso8601_timezone_to_offset($date_bits[7]);
        }
        else
        { // we don't have a timezone, so we assume user local timezone (not server's!)
            $offset = 3600 * get_option('gmt_offset');
        }

        $timestamp = gmmktime($date_bits[4], $date_bits[5], $date_bits[6], $date_bits[2], $date_bits[3], $date_bits[1]);
        $timestamp -= $offset;

        return gmdate('Y-m-d H:i:s', $timestamp);

    }
    else if ($timezone == 'user')
    {
        return preg_replace('#([0-9]{4})([0-9]{2})([0-9]{2})T([0-9]{2}):([0-9]{2}):([0-9]{2})(Z|[\+|\-][0-9]{2,4}){0,1}#', '$1-$2-$3 $4:$5:$6', $date_string);
    }
}

/**
 * Retrieve the current time based on specified type.
 *
 * The 'mysql' type will return the time in the format for MySQL DATETIME field.
 * The 'timestamp' type will return the current timestamp.
 *
 * If $gmt is set to either '1' or 'true', then both types will use GMT time.
 * if $gmt is false, the output is adjusted with the GMT offset in the WordPress option.
 *
 * @param string $type Either 'mysql' or 'timestamp'.
 * @param int|bool $gmt Optional. Whether to use GMT timezone. Default is false.
 * @return int|string String if $type is 'gmt', int if $type is 'timestamp'.
 */
function current_time($type, $gmt = 0)
{
    switch ($type)
    {
        case 'mysql' :
            return ($gmt) ? gmdate('Y-m-d H:i:s') : gmdate('Y-m-d H:i:s', (time() + (get_option('gmt_offset') * 3600)));
            break;
        case 'timestamp' :
            return ($gmt) ? time() : time() + (get_option('gmt_offset') * 3600);
            break;
    }
}
/**
 * Get extended entry info (<!--more-->).
 *
 * There should not be any space after the second dash and before the word
 * 'more'. There can be text or space(s) after the word 'more', but won't be
 * referenced.
 *
 * The returned array has 'main' and 'extended' keys. Main has the text before
 * the <code><!--more--></code>. The 'extended' key has the content after the
 * <code><!--more--></code> comment.
 *
 * @param string $post Post content.
 * @return array Post before ('main') and after ('extended').
 */
function get_extended($post) {
	//Match the new style more links
	if ( preg_match('/<!--more(.*?)?-->/', $post, $matches) ) {
		list($main, $extended) = explode($matches[0], $post, 2);
	} else {
		$main = $post;
		$extended = '';
	}

	// Strip leading and trailing whitespace
	$main = preg_replace('/^[\s]*(.*)[\s]*$/', '\\1', $main);
	$extended = preg_replace('/^[\s]*(.*)[\s]*$/', '\\1', $extended);

	return array('main' => $main, 'extended' => $extended);
}

/**
 * Filters certain characters from the file name.
 *
 * Turns all strings to lowercase removing most characters except alphanumeric
 * with spaces, dashes and periods. All spaces and underscores are converted to
 * dashes. Multiple dashes are converted to a single dash. Finally, if the file
 * name ends with a dash, it is removed.
 *
 *
 * @param string $name The file name
 * @return string Sanitized file name
 */
function sanitize_file_name($name)
{ // Like sanitize_title, but with periods
    $name = strtolower($name);
    $name = preg_replace('/&.+?;/', '', $name); // kill entities
    $name = str_replace('_', '-', $name);
    $name = preg_replace('/[^a-z0-9\s-.]/', '', $name);
    $name = preg_replace('/\s+/', '-', $name);
    $name = preg_replace('|-+|', '-', $name);
    $name = trim($name, '-');
    return $name;
}

/**
 * Retrieve the file type from the file name.
 *
 * You can optionally define the mime array, if needed.
 *
 * @since 2.0.4
 *
 * @param string $filename File name or path.
 * @param array $mimes Optional. Key is the file extension with value as the mime type.
 * @return array Values with extension first and mime type.
 */
function wp_check_filetype($filename, $mimes = null)
{
    // Accepted MIME types are set here as PCRE unless provided.
    $mimes = (is_array($mimes)) ? $mimes : array(
        'jpg|jpeg|jpe' => 'image/jpeg',
        'gif' => 'image/gif',
        'png' => 'image/png',
        'bmp' => 'image/bmp',
        'tif|tiff' => 'image/tiff',
        'ico' => 'image/x-icon',
        'asf|asx|wax|wmv|wmx' => 'video/asf',
        'avi' => 'video/avi',
        'divx' => 'video/divx',
        'mov|qt' => 'video/quicktime',
        'mpeg|mpg|mpe|mp4' => 'video/mpeg',
        'txt|c|cc|h' => 'text/plain',
        'rtx' => 'text/richtext',
        'css' => 'text/css',
        'htm|html' => 'text/html',
        'mp3|m4a' => 'audio/mpeg',
        'ra|ram' => 'audio/x-realaudio',
        'wav' => 'audio/wav',
        'ogg' => 'audio/ogg',
        'mid|midi' => 'audio/midi',
        'wma' => 'audio/wma',
        'rtf' => 'application/rtf',
        'js' => 'application/javascript',
        'pdf' => 'application/pdf',
        'doc|docx' => 'application/msword',
        'pot|pps|ppt|pptx' => 'application/vnd.ms-powerpoint',
        'wri' => 'application/vnd.ms-write',
        'xla|xls|xlsx|xlt|xlw' => 'application/vnd.ms-excel',
        'mdb' => 'application/vnd.ms-access',
        'mpp' => 'application/vnd.ms-project',
        'swf' => 'application/x-shockwave-flash',
        'class' => 'application/java',
        'tar' => 'application/x-tar',
        'zip' => 'application/zip',
        'gz|gzip' => 'application/x-gzip',
        'exe' => 'application/x-msdownload',
        // openoffice formats
        'odt' => 'application/vnd.oasis.opendocument.text',
        'odp' => 'application/vnd.oasis.opendocument.presentation',
        'ods' => 'application/vnd.oasis.opendocument.spreadsheet',
        'odg' => 'application/vnd.oasis.opendocument.graphics',
        'odc' => 'application/vnd.oasis.opendocument.chart',
        'odb' => 'application/vnd.oasis.opendocument.database',
        'odf' => 'application/vnd.oasis.opendocument.formula'
    );

    $type = false;
    $ext = false;

    foreach ($mimes as $ext_preg => $mime_match)
    {
        $ext_preg = '!\.(' . $ext_preg . ')$!i';
        if (preg_match($ext_preg, $filename, $ext_matches))
        {
            $type = $mime_match;
            $ext = $ext_matches[1];
            break;
        }
    }

    return compact('ext', 'type');
}

/**
 * Get a filename that is sanitized and unique for the given directory.
 *
 * If the filename is not unique, then a number will be added to the filename
 * before the extension, and will continue adding numbers until the filename is
 * unique.
 *
 * The callback must accept two parameters, the first one is the directory and
 * the second is the filename. The callback must be a function.
 *
 * @since 2.5
 *
 * @param string $dir
 * @param string $filename
 * @param string $unique_filename_callback Function name, must be a function.
 * @return string New filename, if given wasn't unique.
 */
function wp_unique_filename($dir, $filename, $unique_filename_callback = null)
{
    $filename = strtolower($filename);
    // separate the filename into a name and extension
    $info = pathinfo($filename);
    $ext = !empty($info['extension']) ? $info['extension'] : '';
    $name = basename($filename, ".{$ext}");

    // edge case: if file is named '.ext', treat as an empty name
    if ($name === ".$ext")
        $name = '';

    // Increment the file number until we have a unique file to save in $dir. Use $override['unique_filename_callback'] if supplied.
    if ($unique_filename_callback && function_exists($unique_filename_callback))
    {
        $filename = $unique_filename_callback($dir, $name);
    }
    else
    {
        $number = '';

        if (!empty($ext))
            $ext = strtolower(".$ext");

        $filename = str_replace($ext, '', $filename);
        // Strip % so the server doesn't try to decode entities.
        $filename = str_replace('%', '', $filename) . $ext;

        while (file_exists($dir . "/$filename"))
        {
            if ('' == "$number$ext")
                $filename = $filename . ++$number . $ext;
            else
                $filename = str_replace("$number$ext", ++$number . $ext, $filename);
        }
    }

    return $filename;
}

/**
 * Create a file in the upload folder with given content.
 *
 * If there is an error, then the key 'error' will exist with the error message.
 * If success, then the key 'file' will have the unique file path, the 'url' key
 * will have the link to the new file. and the 'error' key will be set to false.
 *
 * This function will not move an uploaded file to the upload folder. It will
 * create a new file with the content in $bits parameter. If you move the upload
 * file, read the content of the uploaded file, and then you can give the
 * filename and content to this function, which will add it to the upload
 * folder.
 *
 * The permissions will be set on the new file automatically by this function.
 *
 * @param string $name
 * @param mixed $bits File content
 * @param integer $userid author id.
 * @return array
 */
function wp_upload_bits($name, $bits, $userid = 0)
{
    if (empty($name))
        return array(
            'error' => __('Empty filename')
        );

    $name = $userid . '_' . $name;
    $wp_filetype = wp_check_filetype($name);
    if (!$wp_filetype['ext'])
        return array(
            'error' => __('Invalid file type')
        );

    $upload = make_upload_dir();
    $filename = wp_unique_filename($upload['path'], $name);
    $new_file = $upload['path'] . "/$filename";

    if (!wp_mkdir_p(dirname($new_file)))
    {
        $message = sprintf(__('Unable to create directory %s. Is its parent directory writable by the server?'), dirname($new_file));
        return array(
            'error' => $message
        );
    }

    $ifp = @ fopen($new_file, 'wb');
    if (!$ifp)
        return array(
            'error' => sprintf(__('Could not write file %s'), $new_file)
        );

    @fwrite($ifp, $bits);
    fclose($ifp);
    // Set correct file permissions
    $stat = @ stat(dirname($new_file));
    $perms = $stat['mode'] & 0007777;
    $perms = $perms & 0000666;
    @ chmod($new_file, $perms);

    return array(
        'file' => $new_file,
        'url' => $upload['url'] . "/$filename",
        'baseurl' => $upload['baseurl'] . "/$filename",
        'name' => $name,
        'userid' => $userid,
        'error' => false
    );
}

/**
 * Recursive directory creation based on full path.
 *
 * Will attempt to set permissions on folders.
 *
 * @since 2.0.1
 *
 * @param string $target Full path to attempt to create.
 * @return bool Whether the path was created or not. True if path already exists.
 */
function wp_mkdir_p($target)
{
    // from php.net/mkdir user contributed notes
    $target = str_replace('//', '/', $target);
    if (file_exists($target))
        return @is_dir($target);

    // Attempting to create the directory may clutter up our display.
    if (@mkdir($target))
    {
        $stat = @stat(dirname($target));
        $dir_perms = $stat['mode'] & 0007777; // Get the permission bits.
        @chmod($target, $dir_perms);
        return true;
    }
    elseif (is_dir(dirname($target)))
    {
        return false;
    }

    // If the above failed, attempt to create the parent node, then try again.
    if (($target != '/') && (wp_mkdir_p(dirname($target))))
        return wp_mkdir_p($target);

    return false;
}

/**
 * �ϴ��ļ�Ŀ¼
 *
 * @return string Ŀ¼
 */
function make_upload_dir()
{
    global $cfg_medias_dir, $cfg_basedir, $cfg_mediasurl;
    // $cfg_medias_dir = '/dedecms/uploads';
    // $cfg_basedir = 'e:/work/webroot';
    // $cfg_mediasurl = 'http://10.2.20.200/dedecms/uploads';


    $f = '/' . MyDate('ymd', time());
    return array(
        'path' => $cfg_basedir . $cfg_medias_dir . $f,
        'url' => $cfg_mediasurl . $f,
        'baseurl' => $cfg_medias_dir . $f
    );
}

/**
 * Retrieve number of recent posts.
 *
 * @param int $num Optional, default is 10. Number of posts to get.
 * @param int $userid Optional, default is 0. User's posts to get.
 * @return array List of posts.
 */
function get_recent_posts($num = 10, $userid = 0) {
	global $dsql;

	// Set the limit clause, if we got a limit
	$num = (int) $num;
	if ($num) {
		$limit = "LIMIT $num";
	}

	// Set the user clause, if we got a user
	$userid = (int) $userid;
	if ($userid) {
		$user = "And arc.mid = $userid";
	}

	$posts = array();
	$dsql->Execute('posts', "Select arc.id,arc.typeid,arc.typeid2,arc.pubdate,arc.senddate,arc.title,arc.litpic,arc.keywords,arc.notpost,arc.source,aa.body from `#@__archives` arc left join `#@__addonarticle` aa on aa.aid=arc.id where arc.channel > 0 And arc.arcrank > -2 $user order by arc.id desc $limit");
	while($post = $dsql->GetArray('posts'))
	{
		$posts[] = $post;
    }

	return $posts;
}


/**
 * Retrieve a single post, based on post ID.
 *
 * Has categories in 'post_category' property or key. Has tags in 'tags_input'
 * property or key.
 *
 * @since 1.0.0
 *
 * @param int $postid Post ID.
 * @param string $mode How to return result, either OBJECT, ARRAY_N, or ARRAY_A.
 * @return object|array Post object or array holding post contents and information
 */
function get_single_post($postid = 0) {
	global $dsql;

	// Set the limit clause, if we got a limit
	$postid = (int) $postid;
	if (!$postid) {
		return array();
	}

    return $dsql->GetOne("Select arc.id,arc.typeid,arc.typeid2,arc.pubdate,arc.senddate,arc.title,arc.litpic,arc.keywords,arc.notpost,arc.source,arc.description,aa.body from `#@__archives` arc left join `#@__addonarticle` aa on aa.aid=arc.id where arc.id=$postid limit 1");
}

/**
 * �����ϴ��ļ���¼�����ݿ�
 *
 * @param array $upload
 */
function save_upload_to_db(&$upload)
{
    global $dsql;

    $nowtme = time();
    $bfilename = $upload['baseurl'];
    $dbbigfile = basename($upload['file']);
    $bsizes = getimagesize($upload['file']);
    $bimgwidthValue = $bsizes[0];
    $bimgheightValue = $bsizes[1];
    $bimgsize = filesize($upload['file']);
    
    // �����ϴ����¶�����ͼ�Ĵ���
    $bigpicid = (stripos($dbbigfile, $upload['userid'] . '_' . BIGPIC) === false) ? 0 : $upload['userid'];

    $inquery = "INSERT INTO `#@__uploads`(arcid, title,url,mediatype,width,height,playtime,filesize,uptime,mid)
        VALUES ('{$bigpicid}','{$dbbigfile}','$bfilename','1','$bimgwidthValue','$bimgheightValue','0','{$bimgsize}','{$nowtme}','" . $upload['userid'] . "');";
    $dsql->ExecuteNoneQuery($inquery);
}

/**
 * ��ȡ������uploads���е����´�ͼ����ΪLive Writer���ȱ��渽�������������ٱ������ӵġ�
 *
 * @param integer $userid
 */
function get_post_bigpic_from_uploads($userid)
{
    global $dsql;

    return $dsql->GetOne("Select * From `#@__uploads` where arcid = '$userid' ORDER BY uptime DESC limit 1");
}

/**
 * ��ȡϵͳ�����з���
 *
 * @return array ϵͳ����
 */
function get_all_categories()
{
    global $dsql;

    $categroies = array();

    $dsql->SetQuery("Select id,reid,typename From `#@__arctype` order by sortrank");
    $dsql->Execute(0);
    while ($row = $dsql->GetObject(0))
    {
        $categroies[] = array(
            'categoryId' => $row->id,
            'parentId' => $row->reid,
            'description' => $row->typename,
            'categoryDescription' => '',
            'categoryName' => $row->typename,
            'htmlUrl' => '',
            'rssUrl' => ''
        );
    }

    return $categroies;
}

/**
 * ���ݷ�������ȡ����ID
 *
 * @param string $catname ������
 * @return integer ����ID
 */
function get_cat_ID($catname)
{
    $category = get_category_by_catname($catname);

    return intval($category['id']);
}

/**
 * ���ݷ�������ȡ������Ϣ
 *
 * @param string $catname  ������
 * @return array ������Ϣ
 */
function get_category_by_catname($catname)
{
    global $dsql;

    return $dsql->GetOne("Select * From `#@__arctype` where typename = '" . addslashes($catname) . "' limit 1");
}


/**
 * ���ݷ���ID��ȡ�������
 *
 * @param array $ids category ids
 * @return array List of categories.
 */
function get_categorynames_by_catids(&$catids) {
    $categories = get_categories_by_catids($catids);

    $catnames = array();
	foreach($categories AS $category)
	{
		$catnames[] = $category['typename'];
    }

	return $catnames;
}

/**
 * ���ݷ���ID��ȡ������Ϣ
 *
 * @param array $ids category ids
 * @return array List of categories.
 */
function get_categories_by_catids(&$catids) {
	global $dsql;

	$cats = array();
	$dsql->Execute('cats', "Select * From `#@__arctype` where id IN (" . implode(',', $catids) . ")");
	while($cat = $dsql->GetArray('cats'))
	{
		$cats[] = $cat;
    }

	return $cats;
}
