<?php
/**
 * XML-RPC protocol
 *
 * v 0.3
 */

// report not notice error
error_reporting(E_ALL & ~E_NOTICE);

/**
 * Whether this is a XMLRPC Request
 *
 * @var bool
 */
define('XMLRPC_REQUEST', true);

/**
 * Whether to enable XMLRPC Logging.
 *
 * @name xmlrpc_logging
 * @var int|bool
 */
$xmlrpc_logging = 1;

/**
 * DEDECMS url
 *
 * @var string
 */
define('DEDECMS_URL', 'http://localhost/dedecms');

/**
 * ���´�ͼ��ȱʡ�ļ�����bigpic.jpg
 *
 * @var string
 */
define("BIGPIC", "bigpic");

$blog_options = array(
    'software_name' => array(
        'value' => 'XXXXXX'
    ),
    'software_version' => array(
        'value' => '5.3'
    ),
    'blog_url' => array(
        'option' => DEDECMS_URL
    ),
    'time_zone' => array(
        'option' => '8'
    ),
    'gmt_offset' => array(
        'option' => '8'
    ),
    'blog_title' => array(
        'option' => 'XXXXXX News'
    ),
    'blog_tagline' => array(
        'option' => 'News in 3DMAX, MAYA, etc.'
    ),
    'date_format' => array(
        'option' => 'F j, Y'
    ),
    'time_format' => array(
        'option' => 'g:i a'
    ),

    'home' => array(
        'option' => DEDECMS_URL
    ),
    'blogname' => array(
        'option' => 'XXXXXX News'
    ),
    'blog_charset' => array(
        'option' => 'UTF-8'
    ),
    'default_comment_status' => array(
        'option' => 'open'
    )
);
require_once ('./xmlrpc_functions.php');

// Some browser-embedded clients send cookies. We don't want them.
$_COOKIE = array();

// A bug in PHP < 5.2.2 makes $HTTP_RAW_POST_DATA not set by default,
// but we can do it ourself.
if (!isset($HTTP_RAW_POST_DATA))
{
    $HTTP_RAW_POST_DATA = file_get_contents('php://input');
}

// fix for mozBlog and other cases where '<?xml' isn't on the very first line
if (isset($HTTP_RAW_POST_DATA))
{
    $HTTP_RAW_POST_DATA = trim($HTTP_RAW_POST_DATA);
}

/** Include the bootstrap for setting up environment */
require_once ('./include/common.inc.php');
require_once ('./include/userlogin.class.php');
require_once ('./dedeadmincp/inc/inc_archives_functions.php');

if ( isset( $_GET['rsd'] ) ) { // http://archipelago.phrasewise.com/rsd
header('Content-Type: text/xml; charset=' . get_option('blog_charset'), true);
?>
<?php echo '<?xml version="1.0" encoding="'.get_option('blog_charset').'"?'.'>'; ?>
<rsd version="1.0" xmlns="http://archipelago.phrasewise.com/rsd">
  <service>
    <engineName>WordPress</engineName>
    <engineLink>http://wordpress.org/</engineLink>
    <homePageLink><?php bloginfo_rss('url') ?></homePageLink>
    <apis>
      <api name="WordPress" blogID="1" preferred="true" apiLink="<?php echo site_url('xmlrpc.php') ?>" />
      <api name="Movable Type" blogID="1" preferred="false" apiLink="<?php echo site_url('xmlrpc.php') ?>" />
      <api name="MetaWeblog" blogID="1" preferred="false" apiLink="<?php echo site_url('xmlrpc.php') ?>" />
      <api name="Blogger" blogID="1" preferred="false" apiLink="<?php echo site_url('xmlrpc.php') ?>" />
    </apis>
  </service>
</rsd>
<?php
exit;
}

include_once ('class-IXR.php');

if (isset($HTTP_RAW_POST_DATA))
{
    logIO("I", $HTTP_RAW_POST_DATA);
}

/**
 * WordPress XMLRPC server implementation.
 *
 */
class wp_xmlrpc_server extends IXR_Server
{
    /**
     * Current writer
     *
     * @var stdclass
     */
    private $writer = null;

    /**
     * login process
     *
     * @var userLogin
     */
    private $cuserLogin = null;

    /**
     * Register all of the XMLRPC methods that XMLRPC server understands.
     *
     * PHP4 constructor and sets up server and method property. Passes XMLRPC
     * methods through the 'xmlrpc_methods' filter to allow plugins to extend
     * or replace XMLRPC methods.
     *
     * @return wp_xmlrpc_server
     */
    function wp_xmlrpc_server()
    {
        $this->writer = new stdclass();

        $this->methods = array(
            // WordPress API
            'wp.getUsersBlogs' => 'this:wp_getUsersBlogs',
            'wp.getAuthors' => 'this:wp_getAuthors',
            'wp.getCategories' => 'this:mw_getCategories',  // Alias
            'wp.uploadFile' => 'this:mw_newMediaObject',  // Alias
            'wp.getPostStatusList' => 'this:wp_getPostStatusList',
            'wp.getOptions' => 'this:wp_getOptions',

            // Blogger API
            'blogger.getUsersBlogs' => 'this:blogger_getUsersBlogs',
            'blogger.getUserInfo' => 'this:blogger_getUserInfo',
            'blogger.getPost' => 'this:blogger_getPost',
            'blogger.getRecentPosts' => 'this:blogger_getRecentPosts',
            'blogger.getTemplate' => 'this:blogger_getTemplate',
            'blogger.setTemplate' => 'this:blogger_setTemplate',
            'blogger.newPost' => 'this:blogger_newPost',
            'blogger.editPost' => 'this:blogger_editPost',
            'blogger.deletePost' => 'this:blogger_deletePost',

            // MetaWeblog API (with MT extensions to structs)
            'metaWeblog.newPost' => 'this:mw_newPost',
            'metaWeblog.editPost' => 'this:mw_editPost',
            'metaWeblog.getPost' => 'this:mw_getPost',
            'metaWeblog.getRecentPosts' => 'this:mw_getRecentPosts',
            'metaWeblog.getCategories' => 'this:mw_getCategories',
            'metaWeblog.newMediaObject' => 'this:mw_newMediaObject',

            // MetaWeblog API aliases for Blogger API
            // see http://www.xmlrpc.com/stories/storyReader$2460
            'metaWeblog.deletePost' => 'this:blogger_deletePost',
            'metaWeblog.getTemplate' => 'this:blogger_getTemplate',
            'metaWeblog.setTemplate' => 'this:blogger_setTemplate',
            'metaWeblog.getUsersBlogs' => 'this:blogger_getUsersBlogs',

            // MovableType API
            'mt.getCategoryList' => 'this:mt_getCategoryList',
            'mt.getRecentPostTitles' => 'this:mt_getRecentPostTitles',
            'mt.getPostCategories' => 'this:mt_getPostCategories',
            'mt.setPostCategories' => 'this:mt_setPostCategories',
            'mt.supportedMethods' => 'this:mt_supportedMethods',
            'mt.supportedTextFilters' => 'this:mt_supportedTextFilters',
            'mt.getTrackbackPings' => 'this:mt_getTrackbackPings',
            'mt.publishPost' => 'this:mt_publishPost',

            'demo.sayHello' => 'this:sayHello',
            'demo.addTwoNumbers' => 'this:addTwoNumbers'
        );

        $this->initialise_blog_option_info();
        $this->IXR_Server($this->methods);
    }

    /**
     * Test XMLRPC API by saying, "Hello!" to client.
     *
     * @param array $args Method Parameters.
     * @return string
     */
    function sayHello($args)
    {
        return 'Hello!';
    }

    /**
     * Test XMLRPC API by adding two numbers for client.
     *
     * @param array $args Method Parameters.
     * @return int
     */
    function addTwoNumbers($args)
    {
        $number1 = $args[0];
        $number2 = $args[1];
        return $number1 + $number2;
    }

    /**
     * Check user's credentials.
     *
     * @param string $user_login User's username.
     * @param string $user_pass User's password.
     * @return bool Whether authentication passed.
     */
    function login_pass_ok($user_login, $user_pass)
    {
        $this->cuserLogin = new userLogin();
        $ok = 0;
        if (!empty($user_login) && !empty($user_pass))
        {
            $ok = $this->cuserLogin->checkUser($user_login, $user_pass);
        }

        if ($ok != 1)
        {
            $this->error = new IXR_Error(403, __('Bad login/pass combination.'));
            return false;
        }

        // init current write
        $this->writer->userId = $this->cuserLogin->getUserID();
        $this->writer->userName = $user_login;
        $this->writer->password = $user_pass;
        $this->writer->displayName = $this->cuserLogin->getUserName();

        return true;
    }

    /**
     * Sanitize string or array of strings for database.
     *
     * @param string|array $array Sanitize single string or array of strings.
     * @return string|array Type matches $array and sanitized for the database.
     */
    function escape(&$array)
    {
        if (!is_array($array))
        {
            return addslashes($array);
        }
        else
        {
            foreach ((array) $array as $k => $v)
            {
                if (is_array($v))
                {
                    $this->escape($array[$k]);
                }
                else if (is_object($v))
                {
                    //skip
                }
                else
                {
                    $array[$k] = addslashes($v);
                }
            }
        }
    }

    /**
     * Setup blog options property.
     *
     * Passes property through 'xmlrpc_blog_options' filter.
     *
     */
    function initialise_blog_option_info()
    {
        global $blog_options;
        $this->blog_options = $blog_options;
    }

    /**
     * Retrieve the blogs of the user.
     *
     * @param array $args Method parameters.
     * @return array
     */
    function wp_getUsersBlogs($args)
    {
        array_unshift($args, 1);
        return $this->blogger_getUsersBlogs($args);
    }

    /**
     * Retrieve authors list.
     *
     * @param array $args Method parameters.
     * @return array
     */
    function wp_getAuthors($args)
    {

        $this->escape($args);

        $blog_id = (int) $args[0];
        $username = $args[1];
        $password = $args[2];

        if (!$this->login_pass_ok($username, $password))
        {
            return ($this->error);
        }

        $authors[] = array(
            "user_id" => $this->writer->userId,
            "user_login" => $this->writer->userName,
            "display_name" => $this->writer->displayName
        );

        return $authors;
    }

    /**
     * Retrieve post statuses.
     *
     * @since 2.5.0
     *
     * @param array $args Method parameters.
     * @return array
     */
    function wp_getPostStatusList($args)
    {
        $this->escape($args);

        $blog_id = (int) $args[0];
        $username = $args[1];
        $password = $args[2];

        if (!$this->login_pass_ok($username, $password))
        {
            return $this->error;
        }

        $status = array(
            'draft' => __('Draft'),
            'pending' => __('Pending Review'),
            'private' => __('Private'),
            'publish' => __('Published')
        );

        return $status;
    }

    /**
     * Retrieve blog options.
     *
     * @param array $args Method parameters.
     * @return array
     */
    function wp_getOptions($args)
    {
        $this->escape($args);

        $blog_id = (int) $args[0];
        $username = $args[1];
        $password = $args[2];
        $options = (array) $args[3];

        if (!$this->login_pass_ok($username, $password))
        {
            return $this->error;
        }

        // If no specific options where asked for, return all of them
        if (count($options) == 0)
        {
            $options = array_keys($this->blog_options);
        }

        return $this->_getOptions($options);
    }

    /**
     * Retrieve blog options value from list.
     *
     * @param array $options Options to retrieve.
     * @return array
     */
    function _getOptions($options)
    {
        $data = array();
        foreach ($options as $option)
        {
            if (array_key_exists($option, $this->blog_options))
            {
                $data[$option] = $this->blog_options[$option];
                //Is the value static or dynamic?
                if (isset($data[$option]['option']))
                {
                    $data[$option]['value'] = get_option($data[$option]['option']);
                    unset($data[$option]['option']);
                }
            }
        }

        return $data;
    }

    /* Blogger API functions.
	 * specs on http://plant.blogger.com/api and http://groups.yahoo.com/group/bloggerDev/
	 */

    /**
     * Retrieve blogs that user owns.
     *
     * Will make more sense once we support multiple blogs.
     *
     * @param array $args Method parameters.
     * @return array
     */
    function blogger_getUsersBlogs($args)
    {
        $this->escape($args);

        $user_login = $args[1];
        $user_pass = $args[2];

        if (!$this->login_pass_ok($user_login, $user_pass))
        {
            return $this->error;
        }

        $is_admin = 1;
        $struct = array(
            'isAdmin' => $is_admin,
            'url' => get_option('home') . '/',
            'blogid' => '1',
            'blogName' => get_option('blogname'),
            'xmlrpc' => get_option('home') . '/xmlrpc.php'
        );

        return array(
            $struct
        );
    }

    /**
     * Retrieve user's data.
     *
     * Gives your client some info about you, so you don't have to.
     *
     * @param array $args Method parameters.
     * @return array
     */
    function blogger_getUserInfo($args)
    {
        $this->escape($args);

        $user_login = $args[1];
        $user_pass = $args[2];

        if (!$this->login_pass_ok($user_login, $user_pass))
        {
            return $this->error;
        }

        $struct = array(
            'nickname' => $this->writer->displayName,
            'userid' => $this->writer->userId,
            'url' => DEDECMS_URL,
            'lastname' => '',
            'firstname' => ''
        );

        return $struct;
    }

    /**
     * Retrieve post.
     *
     * @param array $args Method parameters.
     * @return array
     */
    function blogger_getPost($args)
    {
        return array();
    }

    /**
     * Retrieve list of recent posts.
     *
     * @param array $args Method parameters.
     * @return array
     */
    function blogger_getRecentPosts($args)
    {
        return array();
    }

    /**
     * Retrieve blog_filename content.
     *
     * @param array $args Method parameters.
     * @return string
     */
    function blogger_getTemplate($args)
    {
        return new IXR_Error(401, __('Sorry, this user can not edit the template.'));
    }

    /**
     * Updates the content of blog_filename.
     *
     * @param array $args Method parameters.
     * @return bool True when done.
     */
    function blogger_setTemplate($args)
    {
        return new IXR_Error(401, __('Sorry, this user can not edit the template.'));
    }

    /**
     * Create new post.
     *
     * @param array $args Method parameters.
     * @return int
     */
    function blogger_newPost($args)
    {
        return new IXR_Error(401, __('Sorry, you are not allowed to post on this blog.'));
    }

    /**
     * Edit a post.
     *
     * @param array $args Method parameters.
     * @return bool true when done.
     */
    function blogger_editPost($args)
    {
        return new IXR_Error(401, __('Sorry, you do not have the right to edit this post.'));
    }

    /**
     * Remove a post.
     *
     * @param array $args Method parameters.
     * @return bool True when post is deleted.
     */
    function blogger_deletePost($args)
    {
        return new IXR_Error(401, __('Sorry, you do not have the right to delete this post.'));
    }

    /**
     * Get comment status
     *
     * @param array $content_struct content struct.
     * @return string comment status
     */
    function _get_comment_status(&$content_struct)
    {
        if (isset($content_struct["mt_allow_comments"]))
        {
            if (!is_numeric($content_struct["mt_allow_comments"]))
            {
                switch ($content_struct["mt_allow_comments"])
                {
                    case "closed" :
                        $comment_status = "closed";
                        break;
                    case "open" :
                        $comment_status = "open";
                        break;
                    default :
                        $comment_status = get_option("default_comment_status");
                        break;
                }
            }
            else
            {
                switch ((int) $content_struct["mt_allow_comments"])
                {
                    case 0 :
                    case 2 :
                        $comment_status = "closed";
                        break;
                    case 1 :
                        $comment_status = "open";
                        break;
                    default :
                        $comment_status = get_option("default_comment_status");
                        break;
                }
            }
        }
        else
        {
            $comment_status = get_option("default_comment_status");
        }

        return $comment_status;
    }

    /* MetaWeblog API functions
	 * specs on wherever Dave Winer wants them to be
	 */

    /**
     * Create a new post.
     *
     * @param array $args Method parameters.
     * @return int
     */
    function mw_newPost($args)
    {
        global $dsql;

        $this->escape($args);

        $blog_ID = (int) $args[0]; // we will support this in the near future
        $user_login = $args[1];
        $user_pass = $args[2];
        $content_struct = $args[3];
        $publish = $args[4];

        if (!$this->login_pass_ok($user_login, $user_pass))
        {
            return $this->error;
        }

        $error_message = __('Sorry, you are not allowed to publish posts on this blog.');
        $post_type = 'post';

        // �����򣬿�����DEDECMS����Դ
        $post_name = "";
        if (isset($content_struct["wp_slug"]))
        {
            $post_name = $content_struct["wp_slug"];
        }

        // ���룬�������������ܸ�
        if (isset($content_struct["wp_password"]))
        {
            $post_password = $content_struct["wp_password"];
        }

        $post_author = $this->writer->userId;

        $post_status = $publish ? 'publish' : 'draft';

        $post_title = $content_struct['title'];
        $post_content = $content_struct['description'];
		$post_more = $content_struct['mt_text_more'];
		if ($post_more) {
			$post_content = $post_content . "<!--more-->" . $post_more;
		}
		$to_ping = '';

        $post_excerpt = $content_struct['mt_excerpt'];
        $tags_input = $content_struct['mt_keywords'];

        $comment_status = $this->_get_comment_status($content_struct);
        $ping_status = "closed";

        // Do some timestamp voodoo
        if (!empty($content_struct['date_created_gmt']))
            $dateCreated = str_replace('Z', '', $content_struct['date_created_gmt']->getIso()) . 'Z'; // We know this is supposed to be GMT, so we're going to slap that Z on there by force
        elseif (!empty($content_struct['dateCreated']))
            $dateCreated = $content_struct['dateCreated']->getIso();

        if (!empty($dateCreated))
        {
            $post_date = get_date_from_gmt(iso8601_to_datetime($dateCreated));
            $post_date_gmt = iso8601_to_datetime($dateCreated, GMT);
        }
        else
        {
            $post_date = current_time('mysql');
            $post_date_gmt = current_time('mysql', 1);
        }

        $catnames = $content_struct['categories'];
        logIO('O', 'Post cats: ' . var_export($catnames, true));
        $post_category = array();
        if (is_array($catnames))
        {
            foreach ($catnames as $cat)
            {
                $post_category[] = get_cat_ID($cat);
            }
        }
        if (empty($post_category))
        {
            return new IXR_Error(500, __('Sorry, you must select a category.'));
        }

        // We've got all the data -- post it:
        $postdata = compact('post_author', 'post_date', 'post_date_gmt', 'post_content', 'post_title', 'post_category', 'post_status', 'post_excerpt', 'comment_status', 'ping_status', 'to_ping', 'post_type', 'post_name', 'post_password', 'post_parent', 'menu_order', 'tags_input');
        logIO("I", var_export($postdata, true));

        // *************************************************** //
        // ������������ID
        $typeid = $post_category[0];
        if (isset($post_category[1]))
        {
            $typeid2 = $post_category[1];
        }
        //$pubdate = GetMkTime($pubdate);
        // ���µķ���ʱ��
        $pubdate = strtotime($post_date_gmt) + get_option('gmt_offset') * 3600;
        // ��ǰд�����ݿ��ʱ��
        $senddate = time() + get_option('gmt_offset') * 3600;
        // ��������Ĭ�����򣬲��ö���
        $sortup = 0;
        $sortrank = AddDay($pubdate, $sortup);
        // ��ͨ
        $channelid = 1;
        $adminid = $this->writer->userId;

        //�����ĵ�ID
        $arcID = GetIndexKey(0, $typeid, $sortrank, $channelid, $senddate, $adminid);
        if (!$arcID)
        {
            return new IXR_Error(500, __('Sorry, your entry could not be posted. Something wrong happened.'));
        }
        // ����ѡ�����HTML($ishtml=1)  ����̬���($ishtml=0)
        $ishtml = 1;
        $ismake = $ishtml == 0 ? -1 : 0;
        // ���±���
        $title = htmlspecialchars(cn_substrR($post_title, 200));
        // ���Ա���
        $shorttitle = cn_substrR($post_title, 36);
        // ������ɫ
        $color = '';
        // ����
        $writer = cn_substrR($this->writer->displayName, 20);
        // ��Դ
        $source = cn_substrR($post_name, 30);
        // ����ժҪ
        $description = cn_substrR($post_excerpt, 250);
        // ��ǩ
        $tags = $tags_input;
        //  �ؼ���
        $keywords = cn_substrR($tags_input, 30);
        // ��������
        $body = $post_content;
        $body = preg_replace(array("#<p>.*?<img.*?_".BIGPIC.".*?>.*?</p>#i","#^\s+#i"), array('', ''), $body, 1);
        //
        $filename = '';
        $userip = GetIP();
        // �Զ������ԣ�ͷ��[h]�Ƽ�[c]ͼƬ[p]�õ�[f]����[s]��ת[j]ͼ��[a]�Ӵ�[b]
        $flag = '';
        // ���ѵ���
        $money = 0;
        // ���µ�����ͼ
        $litpic = '';
        // ����ѡ�0=�������ۣ�1=��ֹ����
        $notpost = ($comment_status == 'open') ? 0 : 1;
        $redirecturl = '';
        $inadd_f = '';
        $inadd_v = '';

        // ���´�ͼ
        $bigpicinfo = get_post_bigpic_from_uploads($adminid);
        $bigpic = empty($bigpicinfo) ? "" : $bigpicinfo['url'];
        
        //���浽����
        $query = "INSERT INTO `#@__archives`(id,typeid,typeid2,sortrank,flag,ismake,channel,arcrank,click,money,title,shorttitle,
        color,writer,source,litpic,pubdate,senddate,mid,notpost,description,keywords,filename, bigpic)
        VALUES ('$arcID','$typeid','$typeid2','$sortrank','$flag','$ismake','$channelid','$arcrank','0','$money',
        '$title','$shorttitle','$color','$writer','$source','$litpic','$pubdate','$senddate',
        '$adminid','$notpost','$description','$keywords','$filename', '$bigpic');";
        if (!$dsql->ExecuteNoneQuery($query))
        {
            $gerr = $dsql->GetError();
            $dsql->ExecuteNoneQuery("Delete From `#@__arctiny` where id='$arcID'");
            return new IXR_Error(500, __('Sorry, fail to save article error to main table: archives.'));
            //"�����ݱ��浽���ݿ����� `#@__archives` ʱ��������������Ϣ�ύ��DedeCms�ٷ���";
        }
        
        // ����uploads���еĴ�ͼ��Ϣ
        if (!empty($bigpicinfo))
        {
            $query = "UPDATE `#@__uploads` SET arcid = '{$arcID}' WHERE aid = '".$bigpicinfo['aid']."'";
            $dsql->ExecuteNoneQuery($query);
        }

        //���浽���ӱ�
        $cts = $dsql->GetOne("Select addtable From `#@__channeltype` where id='$channelid' ");
        $addtable = trim($cts['addtable']);
        if (empty($addtable))
        {
            $dsql->ExecuteNoneQuery("Delete From `#@__archives` where id='$arcID'");
            $dsql->ExecuteNoneQuery("Delete From `#@__arctiny` where id='$arcID'");
            return new IXR_Error(500, __('Sorry, not found channel table.'));
            //"û�ҵ���ǰģ��[{$channelid}]��������Ϣ���޷���ɲ�������"
        }
        $query = "INSERT INTO `{$addtable}`(aid,typeid,redirecturl,userip,body{$inadd_f}) Values('$arcID','$typeid','$redirecturl','$useip','$body'{$inadd_v})";
        if (!$dsql->ExecuteNoneQuery($query))
        {
            $gerr = $dsql->GetError();
            $dsql->ExecuteNoneQuery("Delete From `#@__archives` where id='$arcID'");
            $dsql->ExecuteNoneQuery("Delete From `#@__arctiny` where id='$arcID'");
            return new IXR_Error(500, __('Sorry, fail to save article to addtable.'));
            //"�����ݱ��浽���ݿ⸽�ӱ� `{$addtable}` ʱ��������������Ϣ�ύ��DedeCms�ٷ���"
        }

        //����HTML
        InsertTags($tags, $arcID);
        MakeArt($arcID, true, true);
        // *************************************************** //

        logIO('O', "Posted ! ID: $arcID");
        return strval($arcID);
    }

    /**
     * Edit a post.
     *
     * @param array $args Method parameters.
     * @return bool True on success.
     */
    function mw_editPost($args)
    {
        return new IXR_Error(500, __('Sorry, your entry could not be edited.'));
    }

    /**
     * Retrieve post.
     *
     * @param array $args Method parameters.
     * @return array
     */
    function mw_getPost($args)
    {
        $this->escape($args);

        $post_ID = (int) $args[0];
        $user_login = $args[1];
        $user_pass = $args[2];

        if (!$this->login_pass_ok($user_login, $user_pass))
        {
            return $this->error;
        }

        $entry = get_single_post($post_ID);

        if ($entry['senddate'] != '')
        {
            $post_date = date('Ymd\TH:i:s', $entry['pubdate']);
            $post_date_gmt = date('Ymd\TH:i:s',$entry['pubdate']);

            $catids = array(intval($entry['typeid']), intval($entry['typeid2']));
            $categories = get_categorynames_by_catids($catids);

            $tagnames =$entry['keywords'];

            $post = get_extended($entry['body']);
            $link = '';

            // Get the post author info.
            $author = $this->writer;

            $allow_comments = !$entry['notpost'];
            $allow_pings = 0;

            $resp = array(
                'dateCreated' => new IXR_Date($post_date),
                'userid' => $author->userId,
                'postid' => $entry['id'],
                'description' => $post['main'],
                'title' => $entry['title'],
                'link' => $link,
                'permaLink' => $link,
                // commented out because no other tool seems to use this
                // 'content' => $entry['post_content'],
                'categories' => $categories,
                'mt_excerpt' => $entry['description'],
                'mt_text_more' => $post['extended'],
                'mt_allow_comments' => $allow_comments,
                'mt_allow_pings' => $allow_pings,
                'mt_keywords' => $tagnames,
                'wp_slug' => $entry['source'],
                'wp_password' => '',
                'wp_author_id' => $author->userId,
                'wp_author_display_name' => $author->displayName,
                'date_created_gmt' => new IXR_Date($post_date_gmt),
                'post_status' => 'publish'
            );

            return $resp;
        }
        else
        {
            return new IXR_Error(404, __('Sorry, no such post.'));
        }
    }

    /**
     * Retrieve list of recent posts.
     *
     * @param array $args Method parameters.
     * @return array
     */
    function mw_getRecentPosts($args)
    {
        $this->escape($args);

        $blog_ID = (int) $args[0];
        $user_login = $args[1];
        $user_pass = $args[2];
        $num_posts = (int) $args[3];

        if (!$this->login_pass_ok($user_login, $user_pass))
        {
            return $this->error;
        }

        $posts_list = get_recent_posts($num_posts, $this->writer->userId);

        if (!$posts_list)
        {
            return array();
        }

        foreach ($posts_list as $entry)
        {
            $post_date = date('Ymd\TH:i:s', (intval($entry['pubdate']) + get_option('gmt_offset') * 3600));
            $post_date_gmt = date('Ymd\TH:i:s', (intval($entry['pubdate']) + get_option('gmt_offset') * 3600));

            $catids = array(intval($entry['typeid']), intval($entry['typeid2']));
            $categories = get_categorynames_by_catids($catids);

            $tagnames =$entry['keywords'];

            $post = get_extended($entry['body']);
            $link = '';

            // Get the post author info.
            $author = $this->writer;

            $allow_comments = !$entry['notpost'];
            $allow_pings = 0;

            $struct[] = array(
                'dateCreated' => new IXR_Date($post_date),
                'userid' => $author->userId,
                'postid' => $entry['id'],
                'description' => $post['main'],
                'title' => $entry['title'],
                'link' => $link,
                'permaLink' => $link,
                // commented out because no other tool seems to use this
                // 'content' => $entry['post_content'],
                'categories' => $categories,
                'mt_excerpt' => $entry['description'],
                'mt_text_more' => $post['extended'],
                'mt_allow_comments' => $allow_comments,
                'mt_allow_pings' => $allow_pings,
                'mt_keywords' => $tagnames,
                'wp_slug' => $entry['source'],
                'wp_password' => '',
                'wp_author_id' => $author->userId,
                'wp_author_display_name' => $author->displayName,
                'date_created_gmt' => new IXR_Date($post_date_gmt),
                'post_status' => 'publish'
            );

        }

        $recent_posts = array();
        for ($j = 0; $j < count($struct); $j++)
        {
            array_push($recent_posts, $struct[$j]);
        }

        return $recent_posts;
    }

    /**
     * Retrieve the list of categories on a given blog.
     *
     * @param array $args Method parameters.
     * @return array
     */
    function mw_getCategories($args)
    {
        $this->escape($args);

        $blog_ID = (int) $args[0];
        $user_login = $args[1];
        $user_pass = $args[2];

        if (!$this->login_pass_ok($user_login, $user_pass))
        {
            return $this->error;
        }

        $categories_struct = get_all_categories();
        logIO('O', 'mw_getCategories: ' . var_export($categories_struct, true));
        return $categories_struct;
    }

    /**
     * Uploads a file, following your settings.
     *
     * Adapted from a patch by Johann Richard.
     *
     * @link http://mycvs.org/archives/2004/06/30/file-upload-to-wordpress-in-ecto/
     *
     * @param array $args Method parameters.
     * @return array
     */
    function mw_newMediaObject($args)
    {
        $blog_ID = (int) $args[0];
        $user_login = $this->escape($args[1]);
        $user_pass = $this->escape($args[2]);
        $data = $args[3];

        $name = sanitize_file_name($data['name']);
        $type = $data['type'];
        $bits = $data['bits'];

        logIO('O', '(MW) Received ' . strlen($bits) . ' bytes');

        if (!$this->login_pass_ok($user_login, $user_pass))
            return $this->error;

        $upload = wp_upload_bits($name, $bits, $this->writer->userId);
        if (!empty($upload['error']))
        {
            $errorString = sprintf(__('Could not write file %1$s (%2$s)'), $name, $upload['error']);
            logIO('O', '(MW) ' . $errorString);
            return new IXR_Error(500, $errorString);
        }

        // Save the data
        save_upload_to_db($upload);

        return array(
            'file' => $upload['name'],
            'url' => $upload['url'],
            'type' => $type
        );
    }

    /* MovableType API functions
	 * specs on http://www.movabletype.org/docs/mtmanual_programmatic.html
	 */

    /**
     * Retrieve the post titles of recent posts.
     *
     * @param array $args Method parameters.
     * @return array
     */
    function mt_getRecentPostTitles($args)
    {
        $this->escape($args);

        $blog_ID = (int) $args[0];
        $user_login = $args[1];
        $user_pass = $args[2];
        $num_posts = (int) $args[3];

        if (!$this->login_pass_ok($user_login, $user_pass))
        {
            return $this->error;
        }

        $posts_list = get_recent_posts($num_posts, $this->writer->userId);

        if (!$posts_list)
        {
            $this->error = new IXR_Error(500, __('Either there are no posts, or something went wrong.'));
            return $this->error;
        }

        foreach ($posts_list as $entry)
        {
            $post_date = date('Ymd\TH:i:s', (intval($entry['pubdate']) + get_option('gmt_offset') * 3600));
            $post_date_gmt = date('Ymd\TH:i:s', (intval($entry['pubdate']) + get_option('gmt_offset') * 3600));

            $struct[] = array(
                'dateCreated' => new IXR_Date($post_date),
                'userid' => $this->writer->userId,
                'postid' => $entry['id'],
                'title' => $entry['title'],
                'date_created_gmt' => new IXR_Date($post_date_gmt)
            );

        }

        $recent_posts = array();
        for ($j = 0; $j < count($struct); $j++)
        {
            array_push($recent_posts, $struct[$j]);
        }

        return $recent_posts;
    }

    /**
     * Retrieve list of all categories on blog.
     *
     * @param array $args Method parameters.
     * @return array
     */
    function mt_getCategoryList($args)
    {
        $this->escape($args);

        $blog_ID = (int) $args[0];
        $user_login = $args[1];
        $user_pass = $args[2];

        if (!$this->login_pass_ok($user_login, $user_pass))
        {
            return $this->error;
        }

        $categories_struct = get_all_categories();
        logIO('O', 'mt_getCategoryList: ' . var_export($categories_struct, true));
        return $categories_struct;
    }

    /**
     * Retrieve post categories.
     *
     * @param array $args Method parameters.
     * @return array
     */
    function mt_getPostCategories($args)
    {
        $this->escape($args);

        $post_ID = (int) $args[0];
        $user_login = $args[1];
        $user_pass = $args[2];

        if (!$this->login_pass_ok($user_login, $user_pass))
        {
            return $this->error;
        }

        $entry = get_single_post($post_ID);

        $categories = array();
        $catids = array(intval($entry['typeid']), intval($entry['typeid2']));
        $cats = get_categories_by_catids($catids);
        // first listed category will be the primary category
        $isPrimary = true;
        foreach ($cats as $cat)
        {
            $categories[] = array(
                'categoryName' => $cat['typename'],
                'categoryId' => (string) $cat['id'],
                'isPrimary' => $isPrimary
            );
            $isPrimary = false;
        }

        return $categories;
    }

    /**
     * Sets categories for a post.
     *
     * @param array $args Method parameters.
     * @return bool True on success.
     */
    function mt_setPostCategories($args)
    {
        return true;
    }

    /**
     * Retrieve an array of methods supported by this server.
     *
     * @param array $args Method parameters.
     * @return array
     */
    function mt_supportedMethods($args)
    {
        $supported_methods = array();
        foreach ($this->methods as $key => $value)
        {
            $supported_methods[] = $key;
        }

        return $supported_methods;
    }

    /**
     * Retrieve an empty array because we don't support per-post text filters.
     *
     * @param array $args Method parameters.
     */
    function mt_supportedTextFilters($args)
    {
        return array();
    }

    /**
     * Retrieve trackbacks sent to a given post.
     *
     * @param array $args Method parameters.
     * @return mixed
     */
    function mt_getTrackbackPings($args)
    {
        return array();
    }

    /**
     * Sets a post's publish status to 'publish'.
     *
     * @param array $args Method parameters.
     * @return int
     */
    function mt_publishPost($args)
    {
        $this->escape($args);

        $post_ID = (int) $args[0];
        $user_login = $args[1];
        $user_pass = $args[2];

        if (!$this->login_pass_ok($user_login, $user_pass))
        {
            return $this->error;
        }

        // do nothing

        return $post_ID;
    }

}

$wp_xmlrpc_server = new wp_xmlrpc_server();
?>
