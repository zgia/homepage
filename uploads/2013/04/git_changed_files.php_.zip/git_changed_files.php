<?php
// Rep Dir, do not append a '/' at the end.
define('REPODIR', '/PATH/TO/REPOSITORY');
// Export Dir, do not append a '/' at the end.
define('EXPORTDIR', '/PATH/TO/CHANGED/FILE/EXPORTED');
// Git bin Dir
define('GITBINDIR', '/PATH/TO/GITBIN');

// You can export changed files from $start to HEAD (or other version)
$start = '34d5938';
//$range = "HEAD~1 HEAD";
$range = $start . " HEAD";

// Begin to export
echo "source repository: " . REPODIR . "\n";
echo "exporting to: " . EXPORTDIR . "\n\n";

createDir(EXPORTDIR);

// empty export dirœ
foreach (scandir(EXPORTDIR) as $file) {
	if ($file != '..' && $file != '.') {
		deleteDirRecursive(EXPORTDIR."/$file");
	}
}

// Execute git diff
$cmd = GITBINDIR . "git --git-dir=" . REPODIR . "/.git diff $range --name-only";

exec("{$cmd} 2>&1", $output, $err);

if ($err) {
	echo "Command error: \n";
	echo implode("\n", array_map('htmlspecialchars', $output));
	exit;
}

// $output contains a list of filenames with paths of changed files
foreach ($output as $file) {
	$source = REPODIR . "/$file";

	if (is_file($source)) {
		if (strpos($file, '/')) {
			createDir(EXPORTDIR. "/" . dirname($file));
		}

		copy($source, EXPORTDIR . "/$file");
		echo "$file\n";

	} else {
		// Deleted file
		echo "\n~ERR~ $file\n\n";
	}
}

// Delete cache files
$toDeletingDirs = [];
foreach ($toDeletingDirs as $toDeletingDir)
{
    deleteDirRecursive(EXPORTDIR . $toDeletingDir);
}

/* Create directory if doesn't exist */
function createDir($dirName, $perm = 0777) {
    $dirs = explode('/', $dirName);
    $dir='';
    foreach ($dirs as $part) {
        $dir.=$part.'/';
        if (!is_dir($dir) && strlen($dir)>0) {
            mkdir($dir, $perm);
        }
    }
}

/* Deletes dir recursevely, be careful! */
function deleteDirRecursive($f) {

    if (strpos($f, EXPORTDIR . "/") !== 0) {
        exit("deleteDirRecursive() protection disabled deleting of tree: $f  - please edit the path check in source php file!");
    }

    if (is_dir($f)) {
        foreach(scandir($f) as $item) {
            if ($item == '.' || $item == '..') {
                continue;
            }

            deleteDirRecursive($f . "/" . $item);
        }    
        rmdir($f);

    } elseif (is_file($f)) {
        unlink($f);
    }
}